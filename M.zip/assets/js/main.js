// Theme Toggle
document.getElementById('theme-toggle').addEventListener('click', () => {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update button text
    const button = document.getElementById('theme-toggle');
    button.textContent = newTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
});

// Plugin Execution
document.querySelectorAll('.run-plugin').forEach(button => {
    button.addEventListener('click', function() {
        const pluginName = this.dataset.plugin;
        const target = document.getElementById('target')?.value;
        
        if (!target) {
            alert('Please enter a target URL first');
            return;
        }
        
        // Show loading state
        this.innerHTML = '⌛ Running...';
        
        // Execute plugin
        fetch(`plugins.php?plugin=${pluginName}&target=${encodeURIComponent(target)}`)
            .then(response => response.json())
            .then(data => {
                this.innerHTML = 'Run Plugin';
                showPluginResults(pluginName, data);
            })
            .catch(error => {
                this.innerHTML = 'Run Plugin';
                alert(`Plugin failed: ${error.message}`);
            });
    });
});

// Show plugin results modal
function showPluginResults(pluginName, results) {
    // Implementation would create a modal with results
    console.log(`${pluginName} results:`, results);
    alert(`${pluginName} completed:\n${JSON.stringify(results, null, 2)}`);
}

// Initialize theme
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    // Set button text
    const button = document.getElementById('theme-toggle');
    if (button) {
        button.textContent = savedTheme === 'light' ? '🌙 Dark Mode' : '☀️ Light Mode';
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', initTheme);