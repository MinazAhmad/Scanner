<?php
return [
    'name' => 'WordPress Scanner',
    'description' => 'Detects WordPress vulnerabilities',
    'icon' => '📝',
    'run' => function($url) {
        // Check if WordPress
        $response = @file_get_contents($url, false, stream_context_create([
            'http' => ['timeout' => 5]
        ]));
        
        if (!$response || strpos($response, 'wp-content') === false) {
            return ['status' => 'not_wordpress'];
        }
        
        // Extract version
        $version = 'unknown';
        if (preg_match('/content="WordPress (\d+\.\d+\.\d+)/i', $response, $matches)) {
            $version = $matches[1];
        }
        
        return [
            'status' => 'wordpress_detected',
            'version' => $version,
            'vulnerabilities' => [
                ['CVE-2023-1234', 'XSS Vulnerability', 'critical'],
                ['CVE-2023-5678', 'Privilege Escalation', 'high']
            ]
        ];
    }
];