<?php
/**
 * 🛡️ Ultimate Security Scanner v2.5
 * 
 * Comprehensive security scanning tool with ethical safeguards
 */
class SecurityScanner {
    // Configuration properties
    private $allowedDomains = [];
    private $rateLimits = [];
    private $userAgent = 'EthicalSecurityScanner/2.5 (+https://github.com/ethical-scanner)';
    private $timeout = 15;
    private $maxDepth = 3;
    private $plugins = [];
    private $scanHistory = [];
    
    // Severity mapping
    const SEVERITY_MAP = [
        'xss' => 'high',
        'sqli' => 'critical',
        'command_injection' => 'critical',
        'open_redirect' => 'medium',
        'shell_access' => 'critical',
        'sensitive_file' => 'high',
        'secret_leak' => 'critical'
    ];

    public function __construct(string $authToken) {
        $this->validateToken($authToken);
    }

    private function validateToken(string $token): void {
        // In a real application, we would validate against a stored token
        if ($token !== SECURITY_TOKEN) {
            throw new Exception("Invalid security token");
        }
    }

    /**
     * Add domain to allowed list
     */
    public function addAllowedDomain(string $domain): void {
        $this->allowedDomains[] = $domain;
    }

    /**
     * Load security plugins from directory
     */
    public function loadPlugins(string $directory): void {
        foreach (glob("$directory/*.plugin.php") as $file) {
            $pluginName = basename($file, '.plugin.php');
            $this->plugins[$pluginName] = include $file;
        }
    }

    /**
     * Execute a loaded plugin
     */
    public function executePlugin(string $pluginName, ...$args) {
        if (!isset($this->plugins[$pluginName])) {
            throw new Exception("Plugin $pluginName not loaded");
        }
        return call_user_func_array($this->plugins[$pluginName]['run'], $args);
    }

    /**
     * Get loaded plugins metadata
     */
    public function getLoadedPlugins(): array {
        $metadata = [];
        foreach ($this->plugins as $name => $plugin) {
            $metadata[$name] = [
                'name' => $plugin['name'] ?? $name,
                'description' => $plugin['description'] ?? 'No description',
                'icon' => $plugin['icon'] ?? '🛡️'
            ];
        }
        return $metadata;
    }

    /**
     * Initiate comprehensive security scan
     */
    public function initiateScan(string $targetUrl): array {
        $this->validateTarget($targetUrl);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $this->enforceRateLimit($ip);
        
        $scanId = uniqid('scan_');
        $this->scanHistory[$scanId] = [
            'target' => $targetUrl,
            'start_time' => microtime(true)
        ];
        
        $results = [
            'scan_id' => $scanId,
            'target' => $targetUrl,
            'start_time' => date('c'),
            'crawl' => $this->recursiveCrawl($targetUrl),
            'vulnerabilities' => $this->detectVulnerabilities($targetUrl),
            'headers' => $this->analyzeHeaders($this->fetchRemoteHeaders($targetUrl)),
            'admin_panels' => $this->findAdminPanels($targetUrl),
            'sensitive_files' => $this->scanForCommonFiles($targetUrl),
            'threat_level' => 'pending'
        ];
        
        $results['threat_level'] = $this->calculateThreatLevel($results['vulnerabilities']);
        $results['end_time'] = date('c');
        $results['duration'] = round(microtime(true) - $this->scanHistory[$scanId]['start_time'], 2);
        
        return $results;
    }

    /**
     * Recursive website crawler
     */
    private function recursiveCrawl(string $url, ?int $depth = null, array &$visited = []): array {
        $depth = $depth ?? $this->maxDepth;
        if ($depth <= 0) return $visited;
        
        try {
            $content = $this->fetchRemoteFile($url);
            $visited[$url] = [
                'links' => $this->extractLinks($content, $url),
                'status' => 'scanned',
                'depth' => $this->maxDepth - $depth + 1
            ];

            foreach ($visited[$url]['links'] as $link) {
                if (!isset($visited[$link]) && $this->isSameDomain($url, $link)) {
                    $this->recursiveCrawl($link, $depth - 1, $visited);
                }
            }
        } catch (Exception $e) {
            $visited[$url] = [
                'status' => 'error: ' . $e->getMessage(),
                'depth' => $this->maxDepth - $depth + 1
            ];
        }
        
        return $visited;
    }

    /**
     * Detect security vulnerabilities
     */
    private function detectVulnerabilities(string $url): array {
        $content = $this->fetchRemoteFile($url);
        $html = $this->fetchRemoteFile($url);
        
        return [
            'xss' => $this->detectXSS($content),
            'sqli' => $this->detectSQLi($content),
            'open_redirect' => $this->detectOpenRedirects($html),
            'shell_access' => $this->checkShellAccessPossibility($url) ? ['Potential shell access'] : []
        ];
    }

    /**
     * Detect XSS vulnerabilities
     */
    public function detectXSS(string $content): array {
        $patterns = [
            '/<script\b[^>]*>(.*?)<\/script>/is',
            '/<img\b[^>]*src=["\']?javascript:/i',
            '/<body\b[^>]*onload=["\']/i',
            '/<iframe\b[^>]*src=["\']?javascript:/i',
            '/\beval\s*\(/i',
            '/alert\s*\(/i',
            '/onerror\s*=/i'
        ];
        
        $found = [];
        foreach ($patterns as $pattern) {
            preg_match_all($pattern, $content, $matches);
            if (!empty($matches[0])) {
                $found = array_merge($found, $matches[0]);
            }
        }
        return array_unique($found);
    }

    /**
     * Detect SQL injection patterns
     */
    public function detectSQLi(string $content): array {
        $patterns = [
            '/\b(SELECT\s.+\sFROM\s.+\sWHERE\s.+\s?\=?\s?["\']?\$?\w+)/i',
            '/\b(INSERT\s+INTO\s+.+\sVALUES\s*\([^\)]+\))/i',
            '/\b(UPDATE\s+.+\sSET\s+.+\=\s?["\']?\$?\w+)/i',
            '/\b(DELETE\s+FROM\s+.+\sWHERE\s+.+\=\s?["\']?\$?\w+)/i',
            '/\b(OR\s+\'1\'=\'1\')/i',
            '/\b(UNION\s+SELECT\s+.+)/i',
            '/\b(DROP\s+TABLE\s+.+)/i'
        ];
        
        $found = [];
        foreach ($patterns as $pattern) {
            preg_match_all($pattern, $content, $matches);
            if (!empty($matches[0])) {
                $found = array_merge($found, $matches[0]);
            }
        }
        return array_unique($found);
    }

    /**
     * Detect open redirect vulnerabilities
     */
    public function detectOpenRedirects(string $html): array {
        $patterns = [
            '/\b(redirect|return|url|next|r|uri)=([^&\'"]+)/i',
            '/window\.location\s*=\s*["\']([^"\']+)/i',
            '/http-equiv\s*=\s*["\']?refresh["\']?\s+content\s*=\s*["\']?\d+;url=([^"\']+)/i',
            '/<meta\s+http-equiv="refresh"\s+content="\d+;url=([^"]+)"/i'
        ];
        
        $found = [];
        foreach ($patterns as $pattern) {
            preg_match_all($pattern, $html, $matches);
            if (!empty($matches[1])) {
                $found = array_merge($found, $matches[1]);
            }
        }
        return array_unique($found);
    }

    /**
     * Check for potential shell access
     */
    public function checkShellAccessPossibility(string $url): bool {
        $writablePaths = ['/uploads', '/tmp', '/images', '/assets'];
        foreach ($writablePaths as $path) {
            $testUrl = $this->normalizeUrl($url, $path);
            if ($this->testWritableDirectory($testUrl)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Scan for common sensitive files
     */
    private function scanForCommonFiles(string $baseUrl): array {
        $criticalFiles = [
            '/.env', '/.htaccess', '/web.config',
            '/config.php', '/wp-config.php',
            '/.git/config', '/docker-compose.yml'
        ];
        
        $found = [];
        foreach ($criticalFiles as $file) {
            $url = $this->normalizeUrl($baseUrl, $file);
            try {
                $headers = $this->fetchRemoteHeaders($url);
                $status = explode(' ', $headers[0])[1] ?? '000';
                
                if ($status[0] === '2') {
                    $found[$url] = [
                        'status' => $status,
                        'secrets' => $this->detectSecrets($this->fetchRemoteFile($url))
                    ];
                }
            } catch (Exception $e) {
                // Continue scanning
            }
        }
        
        return $found;
    }

    /**
     * Detect secrets in content
     */
    private function detectSecrets(string $content): array {
        $patterns = [
            'aws_key' => '/AKIA[0-9A-Z]{16}/',
            'google_key' => '/AIza[0-9A-Za-z\\-_]{35}/',
            'credit_card' => '/\b(?:\d[ -]*?){13,16}\b/',
            'jwt_token' => '/eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/',
            'basic_auth' => '/Authorization:\s*Basic\s+([a-zA-Z0-9=]+)/'
        ];
        
        $found = [];
        foreach ($patterns as $type => $pattern) {
            preg_match_all($pattern, $content, $matches);
            if (!empty($matches[0])) {
                $found[$type] = array_unique($matches[0]);
            }
        }
        
        return $found;
    }

    /**
     * Analyze HTTP security headers
     */
    public function analyzeHeaders(array $headers): array {
        $analysis = [
            'csp' => ['present' => false, 'score' => 0],
            'hsts' => ['present' => false, 'score' => 0],
            'xss_protection' => ['present' => false, 'score' => 0],
            'frame_options' => ['present' => false, 'score' => 0],
            'content_type' => ['present' => false, 'score' => 0]
        ];
        
        foreach ($headers as $header) {
            $header = strtolower($header);
            
            if (str_starts_with($header, 'content-security-policy:')) {
                $analysis['csp']['present'] = true;
                $analysis['csp']['score'] = 2;
            }
            if (str_starts_with($header, 'strict-transport-security:')) {
                $analysis['hsts']['present'] = true;
                $analysis['hsts']['score'] = 3;
            }
            if (str_starts_with($header, 'x-xss-protection:')) {
                $analysis['xss_protection']['present'] = true;
                $analysis['xss_protection']['score'] = 1;
            }
            if (str_starts_with($header, 'x-frame-options:')) {
                $analysis['frame_options']['present'] = true;
                $analysis['frame_options']['score'] = 2;
            }
            if (str_starts_with($header, 'x-content-type-options:')) {
                $analysis['content_type']['present'] = true;
                $analysis['content_type']['score'] = 1;
            }
        }
        
        return $analysis;
    }

    /**
     * Find common admin panels
     */
    public function findAdminPanels(string $baseUrl): array {
        $paths = [
            '/admin', '/wp-admin', '/login', 
            '/cpanel', '/administrator', '/manager',
            '/dashboard', '/controlpanel', '/admin.php'
        ];
        
        $found = [];
        foreach ($paths as $path) {
            $url = $this->normalizeUrl($baseUrl, $path);
            try {
                $headers = $this->fetchRemoteHeaders($url);
                $status = explode(' ', $headers[0])[1] ?? '000';
                
                if ($status[0] === '2' || $status[0] === '3') {
                    $found[] = [
                        'url' => $url,
                        'status' => $status
                    ];
                }
            } catch (Exception $e) {
                continue;
            }
        }
        
        return $found;
    }

    /**
     * Calculate threat level
     */
    public function calculateThreatLevel(array $vulns): string {
        $weights = ['critical' => 5, 'high' => 3, 'medium' => 2, 'low' => 1];
        $total = 0;
        
        foreach ($vulns as $type => $items) {
            $severity = $this->determineSeverity($type);
            $total += ($weights[$severity] ?? 1) * count($items);
        }
        
        return match(true) {
            $total >= 20 => 'critical',
            $total >= 10 => 'high',
            $total >= 5 => 'medium',
            default => 'low'
        };
    }

    /**
     * Determine severity for vulnerability type
     */
    public function determineSeverity(string $type): string {
        return self::SEVERITY_MAP[strtolower($type)] ?? 'medium';
    }

    /**
     * Export results in requested format
     */
    public function exportResults(array $results, string $format): void {
        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="scan-results.csv"');
            echo $this->generateCSV($results);
        } else {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="scan-results.json"');
            echo json_encode($results, JSON_PRETTY_PRINT);
        }
        exit;
    }

    /**
     * Generate CSV report
     */
    private function generateCSV(array $results): string {
        $csv = "Target URL, Vulnerability Type, Severity, Count\n";
        foreach ($results['vulnerabilities'] as $type => $items) {
            $severity = $this->determineSeverity($type);
            $csv .= sprintf("\"%s\",\"%s\",\"%s\",\"%d\"\n", 
                $results['target'], $type, $severity, count($items));
        }
        return $csv;
    }

    /**
     * Fetch URL content
     */
    private function fetchRemoteFile(string $url): string {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => $this->userAgent,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS
        ]);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }
        
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode >= 400) {
            throw new Exception("HTTP error $httpCode");
        }
        
        return $response;
    }

    /**
     * Fetch URL headers
     */
    private function fetchRemoteHeaders(string $url): array {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_NOBODY => true,
            CURLOPT_HEADER => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => $this->userAgent,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }
        
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        curl_close($ch);
        
        return array_filter(explode("\r\n", $headers));
    }

    /**
     * Extract links from HTML
     */
    private function extractLinks(string $html, string $baseUrl): array {
        $links = [];
        $dom = new DOMDocument();
        
        @$dom->loadHTML($html);
        
        foreach ($dom->getElementsByTagName('a') as $link) {
            $href = $link->getAttribute('href');
            if ($normalized = $this->normalizeUrl($baseUrl, $href)) {
                $links[] = $normalized;
            }
        }
        
        return array_unique($links);
    }

    /**
     * Normalize URL
     */
    private function normalizeUrl(string $base, string $relative): ?string {
        $relative = trim($relative);
        if (empty($relative)) return null;
        
        // Skip unwanted links
        if (preg_match('/^(javascript:|mailto:|tel:|#)/i', $relative)) {
            return null;
        }
        
        // Already absolute URL
        if (parse_url($relative, PHP_URL_SCHEME)) {
            return filter_var($relative, FILTER_SANITIZE_URL) ?: null;
        }
        
        $baseParts = parse_url($base);
        $result = "{$baseParts['scheme']}://{$baseParts['host']}";
        
        // Handle absolute path
        if (str_starts_with($relative, '/')) {
            return $result . $relative;
        }
        
        // Handle relative path
        $path = isset($baseParts['path']) ? dirname($baseParts['path']) : '';
        return $result . rtrim($path, '/') . '/' . ltrim($relative, '/');
    }

    /**
     * Test if directory is writable
     */
    private function testWritableDirectory(string $url): bool {
        try {
            $testFile = rtrim($url, '/') . '/.scanner_test_' . time();
            $headers = $this->fetchRemoteHeaders($testFile);
            $status = explode(' ', $headers[0])[1] ?? '404';
            return $status == '200';
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Validate target domain
     */
    private function validateTarget(string $url): void {
        $domain = parse_url($url, PHP_URL_HOST);
        
        if (!$domain) {
            throw new Exception("Invalid target URL");
        }
        
        if (!in_array($domain, $this->allowedDomains)) {
            throw new Exception("Scanning not permitted for domain: $domain");
        }
    }

    /**
     * Enforce rate limiting
     */
    private function enforceRateLimit(string $ip): void {
        $now = time();
        
        if (!isset($this->rateLimits[$ip])) {
            $this->rateLimits[$ip] = [
                'count' => 1,
                'timestamp' => $now,
                'last_warning' => 0
            ];
            return;
        }

        $interval = $now - $this->rateLimits[$ip]['timestamp'];
        
        // Reset counter if more than 1 minute passed
        if ($interval > 60) {
            $this->rateLimits[$ip] = [
                'count' => 1,
                'timestamp' => $now,
                'last_warning' => 0
            ];
            return;
        }

        // Enforce limits
        if ($this->rateLimits[$ip]['count'] > 30) {
            throw new Exception("Rate limit exceeded - try again later");
        }
        
        $this->rateLimits[$ip]['count']++;
    }

    /**
     * Check if URLs are same domain
     */
    private function isSameDomain(string $url1, string $url2): bool {
        return parse_url($url1, PHP_URL_HOST) === parse_url($url2, PHP_URL_HOST);
    }

    /**
     * Cleanup resources
     */
    public function cleanup(): void {
        $this->authToken = null;
        $this->rateLimits = [];
    }
}