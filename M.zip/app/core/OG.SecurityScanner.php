<?php
/**
 * 🛡️ Ultimate Security Scanner v2.5
 * 
 * Comprehensive security scanning tool with ethical safeguards
 */
class SecurityScanner {
    // Configuration properties
    private $allowedDomains = [];
    private $rateLimits = [];
    private $userAgent = 'EthicalSecurityScanner/2.5 (+https://github.com/ethical-scanner)';
    private $timeout = 15;
    private $maxDepth = 3;
    private $plugins = [];
    private $scanHistory = [];
    
    // Severity mapping
    const SEVERITY_MAP = [
        'xss' => 'high',
        'sqli' => 'critical',
        'command_injection' => 'critical',
        'open_redirect' => 'medium',
        'shell_access' => 'critical',
        'sensitive_file' => 'high',
        'secret_leak' => 'critical'
    ];

    public function __construct(string $authToken) {
        $this->validateToken($authToken);
    }

    // ... [Include all scanner methods from previous implementation] ...
    
    /**
     * Get loaded plugins metadata
     */
    public function getLoadedPlugins(): array {
        $metadata = [];
        foreach ($this->plugins as $name => $plugin) {
            $metadata[$name] = [
                'name' => $plugin['name'] ?? $name,
                'description' => $plugin['description'] ?? 'No description',
                'icon' => $plugin['icon'] ?? '🛡️'
            ];
        }
        return $metadata;
    }
    
    /**
     * Export results in requested format
     */
    public function exportResults(array $results, string $format): void {
        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="scan-results.csv"');
            echo $this->generateCSV($results);
        } else {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="scan-results.json"');
            echo json_encode($results, JSON_PRETTY_PRINT);
        }
        exit;
    }
    
    private function generateCSV(array $results): string {
        $csv = "Target URL, Vulnerability Type, Severity, Count\n";
        foreach ($results['vulnerabilities'] as $type => $items) {
            $severity = $this->determineSeverity($type);
            $csv .= sprintf("\"%s\",\"%s\",\"%s\",\"%d\"\n", 
                $results['target'], $type, $severity, count($items));
        }
        return $csv;
    }
    
    // ... [Other methods unchanged] ...
}