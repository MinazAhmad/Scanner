<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🛡️ Ethical Security Scanner</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <div class="header-content">
            <h1><span class="logo">🛡️</span> Ethical Security Scanner</h1>
            <div class="controls">
                <button id="theme-toggle">🌙 Dark Mode</button>
                <div class="plugin-count">
                    <span class="badge"><?= count($plugins) ?> plugins</span>
                </div>
            </div>
        </div>
    </header>

    <main>
        <?php if (isset($error)): ?>
            <div class="alert error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <?php if ($view === 'scan-form'): ?>
            <?php include 'scan-form.php'; ?>
        <?php elseif ($view === 'scan-results'): ?>
            <?php include 'scan-results.php'; ?>
        <?php endif; ?>
    </main>

    <footer>
        <p>Ethical Security Scanner v2.5 | Securely scan your web applications</p>
        <p class="disclaimer">
            Use responsibly. Only scan websites you own or have permission to test.
        </p>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>