<?php $results = $_SESSION['scan_results']; ?>

<section class="scan-results">
    <div class="summary-header">
        <h2>Scan Results: <?= htmlspecialchars($results['target']) ?></h2>
        
        <div class="threat-level <?= $results['threat_level'] ?>">
            <?= strtoupper($results['threat_level']) ?> RISK
        </div>
    </div>
    
    <div class="results-container">
        <div class="main-results">
            <?= generateAISummary($results) ?>
            
            <div class="export-actions">
                <a href="?export=json" class="btn">
                    <span class="icon">⬇️</span> JSON Report
                </a>
                <a href="?export=csv" class="btn">
                    <span class="icon">📊</span> CSV Export
                </a>
            </div>
            
            <div class="vulnerability-summary">
                <h3>Vulnerability Overview</h3>
                <ul class="vuln-list">
                    <?php foreach ($results['vulnerabilities'] as $type => $items): ?>
                        <li class="severity-<?= $this->determineSeverity($type) ?>">
                            <span class="vuln-name"><?= ucfirst($type) ?></span>
                            <span class="vuln-count"><?= count($items) ?> found</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        
        <div class="sidebar">
            <div class="result-card">
                <h3>Security Headers</h3>
                <ul>
                    <?php foreach ($results['headers'] as $header => $status): ?>
                        <li class="<?= $status['present'] ? 'good' : 'bad' ?>">
                            <?= strtoupper($header) ?>: 
                            <?= $status['present'] ? '✅ Present' : '❌ Missing' ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <div class="result-card">
                <h3>Sensitive Files Found</h3>
                <?php if (!empty($results['sensitive_files'])): ?>
                    <ul>
                        <?php foreach ($results['sensitive_files'] as $file => $details): ?>
                            <li><?= htmlspecialchars(basename($file)) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="good">No sensitive files detected ✅</p>
                <?php endif; ?>
            </div>
            
            <div class="result-card">
                <h3>Admin Interfaces</h3>
                <?php if (!empty($results['admin_panels'])): ?>
                    <ul>
                        <?php foreach ($results['admin_panels'] as $panel): ?>
                            <li><?= htmlspecialchars($panel['url']) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="good">No admin panels found ✅</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="technical-details">
        <details>
            <summary>Technical Details</summary>
            <pre><?= htmlspecialchars(json_encode($results, JSON_PRETTY_PRINT)) ?></pre>
        </details>
    </div>
</section>