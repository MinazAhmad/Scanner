<section class="scan-form">
    <h2>Website Security Scan</h2>
    
    <form method="POST">
        <input type="hidden" name="scan" value="1">
        
        <div class="form-group">
            <label for="target">Website URL:</label>
            <input type="url" id="target" name="target" 
                   placeholder="https://example.com" required
                   pattern="https?://.+" title="Include http:// or https://">
        </div>
        
        <div class="form-group">
            <label for="depth">Scan Depth:</label>
            <select id="depth" name="depth">
                <option value="1">Lightning (Quick)</option>
                <option value="2" selected>Standard</option>
                <option value="3">Deep Scan</option>
            </select>
        </div>
        
        <div class="form-actions">
            <button type="submit">
                <span class="scan-icon">🔍</span> Start Security Scan
            </button>
        </div>
    </form>
    
    <div class="plugin-grid">
        <h3>Security Plugins</h3>
        <div class="plugins">
            <?php foreach ($plugins as $name => $plugin): ?>
                <div class="plugin-card">
                    <div class="plugin-icon"><?= $plugin['icon'] ?? '🛡️' ?></div>
                    <h4><?= htmlspecialchars($plugin['name']) ?></h4>
                    <p><?= htmlspecialchars($plugin['description']) ?></p>
                    <button class="run-plugin" 
                            data-plugin="<?= htmlspecialchars($name) ?>"
                            data-target="#target">
                        Run Plugin
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>