<?php
// Security token (auto-generated on first run)
if (!defined('SECURITY_TOKEN')) {
    $tokenFile = __DIR__ . '/.token';
    if (!file_exists($tokenFile)) {
        $token = bin2hex(random_bytes(32));
        file_put_contents($tokenFile, $token);
    }
    define('SECURITY_TOKEN', file_get_contents($tokenFile));
}

// Path constants
define('PLUGIN_DIR', __DIR__ . '/plugins');
define('TEMPLATE_DIR', __DIR__ . '/templates');
define('LOG_DIR', __DIR__ . '/logs');
define('MAINTENANCE_MODE', false);

// Create directories if missing
@mkdir(LOG_DIR, 0755, true);
@mkdir(PLUGIN_DIR, 0755, true);

// Error logging
ini_set('log_errors', 1);
ini_set('error_log', LOG_DIR . '/errors.log');

// AI Summary Generator
function generateAISummary(array $results): string {
    $level = $results['threat_level'];
    $vulns = count($results['vulnerabilities']);
    $files = count($results['sensitive_files']);
    
    $summary = "<div class='ai-summary'>";
    $summary .= "<h3><i class='ai-icon'></i> AI Security Assessment</h3>";
    
    $summary .= match($level) {
        'critical' => "<p class='critical'>🚨 <strong>Critical Threat</strong>: Immediate action required! Found $vulns vulnerabilities including critical risks.",
        'high'     => "<p class='high'>⚠️ <strong>High Risk</strong>: Urgent attention needed. Detected $vulns security vulnerabilities.",
        'medium'   => "<p class='medium'>🔍 <strong>Medium Risk</strong>: Needs improvement. Found $vulns security issues.",
        default    => "<p class='low'>✅ <strong>Low Risk</strong>: Good security posture. Minimal issues found."
    };
    
    $summary .= " $files sensitive files exposed.</p>";
    
    $summary .= "<div class='recommendations'>";
    $summary .= "<h4>Recommendations:</h4><ul>";
    $summary .= "<li>Update all software components</li>";
    
    if ($results['headers']['csp']['present'] === false) {
        $summary .= "<li>Implement Content Security Policy</li>";
    }
    
    if ($files > 0) {
        $summary .= "<li>Secure exposed sensitive files</li>";
    }
    
    if (!empty($results['admin_panels'])) {
        $summary .= "<li>Harden administrative interfaces</li>";
    }
    
    $summary .= "<li>Schedule regular security scans</li>";
    $summary .= "</ul></div></div>";
    
    return $summary;
}


// Ensure logs directory exists
if (!is_dir(LOG_DIR)) {
    mkdir(LOG_DIR, 0755, true);
    file_put_contents(LOG_DIR . '/.htaccess', "Deny from all");
}